package com.example.projectapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.projectapp.util.Constants;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.HashMap;
import java.util.Map;

public class ProBuyAct extends AppCompatActivity {
    private static final int REQUEST_CALL = 999;
    private AppCompatTextView ownerenroll, ownername, ownercontact, ownerroom;
    private AppCompatButton contactBtn;
    private StringRequest stringRequest;
    private VolleySingleton volleySingleton;
    public static final String KEY_ID = "eid";
    String eid;
    private static SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pro_buy);
        ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#1E0233"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setTitle("ASE");
        preferences = getSharedPreferences("mypref", MODE_PRIVATE);
        editor = preferences.edit();
        init();
    }

    private void init() {
        ownerenroll = findViewById(R.id.ownerenroll);
        ownername = findViewById(R.id.ownername);
        ownercontact = findViewById(R.id.ownercontact);
        ownerroom = findViewById(R.id.ownerroom);
        contactBtn = findViewById(R.id.contactBtn);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Bundle bundle = getIntent().getExtras();
        eid = bundle.getString("eid");
        buyerDetails();
        contactBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makeCall();
            }
        });
    }

    private void makeCall() {
        String number = ownercontact.getText().toString();
        if(number.trim().length() > 0)
        {
            if(ContextCompat.checkSelfPermission(ProBuyAct.this,
                    Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(ProBuyAct.this,
                        new String[] {Manifest.permission.CALL_PHONE}, REQUEST_CALL);
            } else{
                String dial = "tel:" + number;
                startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
            }

        } else{
            Toast.makeText(getApplicationContext(), "Please enter Contact", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode  == REQUEST_CALL)
        {
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_DENIED)
            {
                makeCall();
            }
            else
                Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
        }
    }

    private void buyerDetails() {
        if(eid != null)
        {
            stringRequest = new StringRequest(Request.Method.POST, Constants.OWNER_DETAILS, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.i("INFOWNER", response);
                    //Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                    try{
                        JSONArray jsonArray = new JSONArray(response);
                        ownerenroll.setText(jsonArray.getString(0));
                        ownername.setText(jsonArray.getString(1));
                        ownercontact.setText(jsonArray.getString(2));
                        ownerroom.setText(jsonArray.getString(3));
                    } catch (JSONException ex)
                    {
                        Log.e("ERROR", ex.getMessage());
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("ERROR", error.toString());
                }
            })
            {
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> hashMap = new HashMap<>();
                    hashMap.put(KEY_ID, eid);
                    return hashMap;
                }
            };
            volleySingleton = VolleySingleton.getInstance(this);
            volleySingleton.addToRequestQueue(stringRequest);
        }

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id =item.getItemId();
        if(id == R.id.logout)
        {
            editor = preferences.edit();
            editor.remove("eid");
            editor.remove("password");
            editor.clear();
            editor.apply();
            Intent intent = new Intent(getApplicationContext(), LoginAct.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }
        else if(id == R.id.profile)
        {
            Intent intent = new Intent(getApplicationContext(), ProfileAct.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
        else if(id == R.id.history1)
        {
            startActivity(new Intent(getApplicationContext(), History.class));
        }
        else if(id == R.id.home)
        {
            startActivity(new Intent(getApplicationContext(), HomeAct.class));
        }
        return true;
    }
}