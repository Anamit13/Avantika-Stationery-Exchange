package com.example.projectapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projectapp.R;
import com.example.projectapp.model.Product;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.HomeHolder> {

    private Context context;
    private ArrayList<Product> arrayList;
    public static onItemClickListener listener;
    public interface onItemClickListener{
        void onItemClick(int position);
    }
    public void setOnItemClickListener(onItemClickListener listener){
        this.listener = listener;
    }

    public HomeAdapter(Context context, ArrayList<Product> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public HomeHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.homecard, parent, false);
        return new HomeHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HomeHolder holder, int position) {
        Product mProducts  = arrayList.get(position);
        Picasso.get().load(mProducts.getPimage()).centerCrop().fit().noFade().into(holder.homeproductimage);
        holder.homepname.setText(mProducts.getPname());
        holder.productprice.setText(mProducts.getSprice());

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public static class HomeHolder extends RecyclerView.ViewHolder{
        private CircleImageView homeproductimage;
        private AppCompatTextView homepname, productprice;

        public HomeHolder(@NonNull View itemView) {
            super(itemView);
            homeproductimage = itemView.findViewById(R.id.homeproductimage);
            homepname = itemView.findViewById(R.id.homepname);
            productprice = itemView.findViewById(R.id.productprice);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(listener != null)
                    {
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION)
                            listener.onItemClick(position);
                    }
                }
            });
        }
    }
}
