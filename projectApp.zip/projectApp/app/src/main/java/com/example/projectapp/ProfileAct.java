package com.example.projectapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.projectapp.adapter.ProfileAdapter;
import com.example.projectapp.model.Product;
import com.example.projectapp.util.Constants;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileAct extends AppCompatActivity implements View.OnClickListener, ProfileAdapter.OnItemClickListener {
    private static final int PICK_IMAGE_REQUEST = 1;
    private AppCompatImageView clickimg, uploadimg;
    private CircleImageView profileimage;
    private AppCompatTextView pname, pid, pcontact, proom, notAvailableProfile;
    private RecyclerView recyclerViewprofile;
    private ProfileAdapter adapter;
    private ArrayList<Product> products;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    FragmentManager fm = getSupportFragmentManager();
    private StringRequest stringRequest;
    private StringRequest stringRequest1, stringRequest2;
    private VolleySingleton singleton;
    private VolleySingleton singleton1, singleton2;
    private Bitmap bitmap;
    public static final String KEY_ID = "eid";
    public static final String KEY_PID = "pid";
    public static final String KEY_IMAGE = "image";
    private Button button;
    private ProgressDialog progressDialog;

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#1E0233"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setTitle("ASE");
        preferences = getSharedPreferences("mypref", MODE_PRIVATE);
        editor = preferences.edit();

        init();
        recyclerViewprofile.setLayoutManager(new GridLayoutManager(this, 1));
        recyclerViewprofile.setHasFixedSize(true);
        products = new ArrayList<>();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        uploadimg.setOnClickListener(this);
        progressDialog = new ProgressDialog(this);
        pname.setText(preferences.getString("name", ""));
        pid.setText(preferences.getString("eid", ""));
        pcontact.setText(preferences.getString("contact", ""));
        proom.setText(preferences.getString("room", ""));
        String image = preferences.getString("image", "");
        if(!image.equals("null")){
            Picasso.get().load(image).into(profileimage);
        }else{
            profileimage.setImageResource(R.drawable.user);
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        clickimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickImage();
            }
        });
        productData();
    }

    private void productData() {
        products.clear();
        progressDialog.setCancelable(false);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Loading.... Please wait");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.create();
        progressDialog.show();
        String eid = preferences.getString("eid", "");
        stringRequest1 = new StringRequest(Request.Method.POST, Constants.PROFILE_PRO, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("INFO", response);
                progressDialog.dismiss();
                if(response.equals("empty"))
                    notAvailableProfile.setVisibility(View.VISIBLE);
                else
                {
                    try{
                        JSONObject jsonObject = new JSONObject(response);
                        JSONArray jsonArray = jsonObject.getJSONArray("data");
                        for(int i = 0; i < jsonArray.length(); i++)
                        {
                            JSONObject jOBj = jsonArray.getJSONObject(i);
                            Product mProducts = new Product(jOBj.getString("pname"), jOBj.getString("pid"));
                            products.add(mProducts);
                        }
                        adapter = new ProfileAdapter(ProfileAct.this, products);
                        recyclerViewprofile.setAdapter(adapter);
                        adapter.setOnItemClickListener(ProfileAct.this);

                    } catch (JSONException ex)
                    {
                        progressDialog.cancel();
                        Log.e("JSON", ex.getMessage());
                    }
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("ERROR", error.toString());
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        })
        {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put(KEY_ID, eid);
                return hashMap;
            }
        };
        singleton1 = VolleySingleton.getInstance(this);
        singleton1.addToRequestQueue(stringRequest1);
    }

    public void pickImage(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"),
                PICK_IMAGE_REQUEST);
    }
    private String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }

    public void init()
    {
        pname = findViewById(R.id.pname);
        pid = findViewById(R.id.pid);
        pcontact = findViewById(R.id.pcontact);
        proom = findViewById(R.id.proom);
        profileimage = findViewById(R.id.profileimage);
        clickimg = findViewById(R.id.clickimg);
        uploadimg = findViewById(R.id.uploadimg);
        recyclerViewprofile = findViewById(R.id.recyclerViewprofile);
        button = findViewById(R.id.Share_UpBtn);
        notAvailableProfile = findViewById(R.id.notAvailableProfile);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id =item.getItemId();
        if(id == R.id.logout)
        {
            editor = preferences.edit();
            editor.remove("eid");
            editor.remove("password");
            editor.clear();
            editor.apply();
            Intent intent = new Intent(getApplicationContext(), LoginAct.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }
        else if(id == R.id.profile)
        {
            Intent intent = new Intent(getApplicationContext(), ProfileAct.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
        else if(id == R.id.history1)
        {
            startActivity(new Intent(getApplicationContext(), History.class));
        }
        else if(id == R.id.home)
        {
            startActivity(new Intent(getApplicationContext(), HomeAct.class));
        }
        return true;
    }

    @Override
    public void onClick(View v) {
        if(v == uploadimg)
            updateUser();
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST &&
                resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri filePath = data.getData();
            try {
                //Getting the Bitmap from Gallery
                profileimage.setVisibility(View.VISIBLE);
                bitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), filePath);
                //Setting the Bitmap to ImageView
                profileimage.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    private void updateUser() {
        String imgurl = getStringImage(bitmap);
        String eid = pid.getText().toString().trim();
        if(imgurl != null && eid != null)
        {
            stringRequest = new StringRequest(Request.Method.POST, Constants.IMAGE_URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.i("INFO", response);
                    if(response.equals("success"))
                    {
                        Toast.makeText(getApplicationContext(), "SUCCESS", Toast.LENGTH_SHORT).show();
                    }
                    else
                        Toast.makeText(getApplicationContext(), "Failed", Toast.LENGTH_SHORT).show();

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("ERROR", error.toString());
                    Toast.makeText(getApplicationContext(),error.toString(), Toast.LENGTH_SHORT).show();
                }
            })
            {
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> hashMap = new HashMap<>();
                    hashMap.put(KEY_ID, eid);
                    hashMap.put(KEY_IMAGE, imgurl);
                    return hashMap;
                }

            };
            singleton =VolleySingleton.getInstance(this);
            singleton.addToRequestQueue(stringRequest);
        }
    }
    public void deletePro()
    {

    }


    @Override
    public void onItemClick(int position) {
        Product mproducts = products.get(position);
        String pid = (String) mproducts.getPid();
        editor = preferences.edit();
        editor.putString("pid", pid);
        editor.apply();
        editor.commit();
        PopUp popUp = new PopUp();
        popUp.show(fm, "Dialog Fragment");
    }
}