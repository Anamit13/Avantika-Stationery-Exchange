package com.example.projectapp.model;

import java.io.Serializable;

public class Product implements Serializable {
    private String eid;
    private String pname;
    private String pdesc;
    private String oprice;
    private String sprice;
    private String ownership;
    private String pimage;
    private String pid;

    public Product(String pname, String sprice, String pimage) {
        this.pname = pname;
        this.sprice = sprice;
        this.pimage = pimage;
    }

    public Product(String pname, String pid) {
        this.pname = pname;
        this.pid = pid;
    }


    public Product(String eid, String pname, String pdesc, String oprice, String sprice, String ownership, String pimage) {
        this.eid = eid;
        this.pname = pname;
        this.pdesc = pdesc;
        this.oprice = oprice;
        this.sprice = sprice;
        this.ownership = ownership;
        this.pimage = pimage;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public Product() {
    }

    public Product(String pname) {
        this.pname = pname;
    }

    public String getPimage() {
        return pimage;
    }

    public void setPimage(String pimage) {
        this.pimage = pimage;
    }



    public String getEid() {
        return eid;
    }

    public void setEid(String eid) {
        this.eid = eid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getPdesc() {
        return pdesc;
    }

    public void setPdesc(String pdesc) {
        this.pdesc = pdesc;
    }

    public String getOprice() {
        return oprice;
    }

    public void setOprice(String oprice) {
        this.oprice = oprice;
    }

    public String getSprice() {
        return sprice;
    }

    public void setSprice(String sprice) {
        this.sprice = sprice;
    }

    public String getOwnership() {
        return ownership;
    }

    public void setOwnership(String ownership) {
        this.ownership = ownership;
    }
}
