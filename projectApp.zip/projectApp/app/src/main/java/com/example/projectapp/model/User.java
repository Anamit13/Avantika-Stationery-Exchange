package com.example.projectapp.model;

import java.io.Serializable;

public class User implements Serializable {

    private String uid;
    private String uname;
    private String contact;
    private String roomNo;
    private String question;
    private String password;

    public User(){};

    public User(String uid, String uname, String contact, String roomNo, String question, String password) {
        this.uid = uid;
        this.uname = uname;
        this.contact = contact;
        this.roomNo = roomNo;
        this.question = question;
        this.password = password;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getRoomNo() {
        return roomNo;
    }

    public void setRoomNo(String roomNo) {
        this.roomNo = roomNo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
