package com.example.projectapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.projectapp.util.Constants;

import java.util.HashMap;
import java.util.Map;

public class PopUp extends DialogFragment implements View.OnClickListener {
    public static final String KEY_ID= "eid";
    public static final String KEY_PID= "pid";
    public static final String KEY_BUYERID= "buyerid";

    private EditText name;
    Button joinBtn;
    ImageView Close_Popup;
    String Token="" ;
    String EventId;
    private String username;
    private String eid, pid;
    public SharedPreferences preferences;
    private VolleySingleton singleton, singleton1;
    private StringRequest stringRequest, stringRequest1;
    private VolleySingleton AppStatus;

    public PopUp() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootview = inflater.inflate(R.layout.fragment_pop_up, container, false);
        getDialog().setCanceledOnTouchOutside(true);
        preferences = this.getActivity().getSharedPreferences("mypref", Activity.MODE_PRIVATE);
        eid = preferences.getString("eid", "");
        pid = preferences.getString("pid", "");
        joinBtn = (Button) rootview.findViewById(R.id.Share_UpBtn);
        name = (EditText) rootview.findViewById(R.id.Share_editName);
        Close_Popup = (ImageView)rootview.findViewById(R.id.Close_Popup_Share);
        Close_Popup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        joinBtn.setOnClickListener(this);

        return rootview;
    }

    public void send_buyerid(){
        username = name.getText().toString().trim();

        if(eid != "" && pid != "" && eid != null && pid != null && username != null)
        {
            stringRequest = new StringRequest(Request.Method.POST, Constants.BUYER_DETAILS, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.i("INFO", response);
                    if (response.equals("success"))
                        Toast.makeText(getActivity(), "Product deleted", Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(getActivity(), "Enter valid enrollment id", Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("ERROR", error.toString());
                    Toast.makeText(getActivity(), "Please fill the fields", Toast.LENGTH_SHORT).show();
                }
            })
            {
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> hashMap = new HashMap<>();
                    hashMap.put(KEY_ID, eid);
                    hashMap.put(KEY_PID, pid);
                    hashMap.put(KEY_BUYERID, username);
                    return hashMap;
                }
            };
            singleton = VolleySingleton.getInstance(getActivity());
            singleton.addToRequestQueue(stringRequest);
        }


    }

    private void deletePro()
    {
        String eid = preferences.getString("eid", "");
        String pid = preferences.getString("pid", "");
        stringRequest1 = new StringRequest(Request.Method.POST, Constants.DELETE_PRO, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("INFO", response);
                if(response.equals("success"))
                    Toast.makeText(getActivity(), "Deleted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getActivity(), response, Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        })
        {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put(KEY_ID, eid);
                hashMap.put(KEY_PID, pid);
                return hashMap;
            }
        };
        singleton1 = VolleySingleton.getInstance(getActivity());
        singleton1.addToRequestQueue(stringRequest1);
    }

    @Override
    public void onClick(View v) {
        String uname = name.getText().toString().trim();
        if(uname.equals("") || uname.equals(null))
        {
            name.setError("Full name can't be empty");
            return;

        }
        else{
            if (singleton.getInstance(getActivity()).isOnline()) {
                send_buyerid();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        deletePro();
                    }
                }, 5000);


                //           Toast.makeText(this,"You are online!!!!",Toast.LENGTH_LONG).show();

            } else {

                ContextThemeWrapper ctw = new ContextThemeWrapper( getActivity(), R.style.Theme_AlertDialog);
                final android.app.AlertDialog.Builder alertDialogBuilder = new android.app.AlertDialog.Builder(ctw);
                alertDialogBuilder.setTitle("No internet connection");
                alertDialogBuilder.setMessage("Check your  internet connection or try again");
                alertDialogBuilder.setNegativeButton("Setting", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivityForResult(new Intent(android.provider.Settings.ACTION_SETTINGS), 0);
                    }
                });
                alertDialogBuilder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });
                alertDialogBuilder.show();
            }
        }

    }
}