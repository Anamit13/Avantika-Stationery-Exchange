package com.example.projectapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.projectapp.adapter.HistoryAdapter;
import com.example.projectapp.util.Constants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class History extends AppCompatActivity {
    private StringRequest stringRequest;
    private VolleySingleton singleton;
    private RecyclerView recyclerView;
    private HistoryAdapter adapter;
    private ArrayList<com.example.projectapp.model.History> history;
    private static SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    private AppCompatTextView notAvailablehistory;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#1E0233"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setTitle("ASE");
        preferences = getSharedPreferences("mypref", MODE_PRIVATE);
        editor = preferences.edit();
        notAvailablehistory = findViewById(R.id.notAvailableHistory);
        recyclerView = findViewById(R.id.recyclerViewHistory);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1));
        recyclerView.setHasFixedSize(true);
        history = new ArrayList<>();
        progressDialog = new ProgressDialog(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        historyData();
    }

    private void historyData() {
        history.clear();
        progressDialog.setCancelable(false);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Loading.... Please wait");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.create();
        progressDialog.show();
        stringRequest = new StringRequest(Request.Method.POST, Constants.HISTORY_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("INFO", response);
                progressDialog.dismiss();
                if(response.equals("empty"))
                    notAvailablehistory.setVisibility(View.VISIBLE);
                else{
                    try{
                        JSONObject jsonObject = new JSONObject(response);
                        JSONArray jsonarray = jsonObject.getJSONArray("data");
                        for(int i = 0; i < jsonarray.length(); i++)
                        {
                            JSONObject jOBj = jsonarray.getJSONObject(i);
                            com.example.projectapp.model.History mHistory = new com.example.projectapp.model.History(jOBj.getString("product"),
                                    jOBj.getString("seller"), jOBj.getString("buyer"));
                            history.add(mHistory);
                        }
                        adapter = new HistoryAdapter(History.this, history);
                        recyclerView.setAdapter(adapter);

                    } catch (JSONException ex)
                    {
                        progressDialog.cancel();
                        Log.e("ERROR", ex.getMessage());
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        singleton = VolleySingleton.getInstance(this);
        singleton.addToRequestQueue(stringRequest);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id =item.getItemId();
        if(id == R.id.logout)
        {
            editor = preferences.edit();
            editor.remove("eid");
            editor.remove("password");
            editor.clear();
            editor.apply();
            Intent intent = new Intent(getApplicationContext(), LoginAct.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }
        else if(id == R.id.profile)
        {
            Intent intent = new Intent(getApplicationContext(), ProfileAct.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
        else if(id == R.id.history1)
        {
            startActivity(new Intent(getApplicationContext(), History.class));
        }
        else if(id == R.id.home)
        {
            startActivity(new Intent(getApplicationContext(), HomeAct.class));
        }
        return true;
    }

}