package com.example.projectapp.model;

import java.io.Serializable;

public class History implements Serializable {
    private String product;
    private String seller;
    private String buyer;

    public History(String product, String seller, String buyer) {
        this.product = product;
        this.seller = seller;
        this.buyer = buyer;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getSeller() {
        return seller;
    }

    public void setSeller(String seller) {
        this.seller = seller;
    }

    public String getBuyer() {
        return buyer;
    }

    public void setBuyer(String buyer) {
        this.buyer = buyer;
    }
}
