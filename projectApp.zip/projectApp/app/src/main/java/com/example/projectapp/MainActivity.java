package com.example.projectapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {
    private SharedPreferences preferences;
    private String eid;
    private String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        preferences = getSharedPreferences("mypref", MODE_PRIVATE);
        eid =preferences.getString("eid", "");
        password = preferences.getString("password", "");
        getSupportActionBar().hide();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                Intent intent;
                if(!eid.equals("") && !password.equals(""))
                {
                    intent = new Intent(getApplicationContext(), HomeAct.class);
                }else
                    intent = new Intent(getApplicationContext(), LoginAct.class);
                startActivity(intent);
            }
        },3000);
    }
}

