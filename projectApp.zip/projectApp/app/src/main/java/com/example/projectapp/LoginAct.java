package com.example.projectapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.projectapp.model.User;
import com.example.projectapp.util.Constants;

import java.util.HashMap;
import java.util.Map;

public class LoginAct extends AppCompatActivity implements View.OnClickListener {
    private static AppCompatEditText idEdit, passwordEdit;
    private AppCompatButton Btn;
    private AppCompatTextView registerText, forgotPassword;
    private SharedPreferences preferences;
    private StringRequest stringRequest;
    private VolleySingleton singleton;
    private static final String KEY_ID = "eid";
    private static final String KEY_PASSWORD = "password";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        preferences = getSharedPreferences("mypref", MODE_PRIVATE);
        init();
        getSupportActionBar().hide();
    }

    private void init() {
        idEdit = findViewById(R.id.idEdit);
        passwordEdit = findViewById(R.id.passwordEdit);
        Btn = findViewById(R.id.Btn);
        registerText = findViewById(R.id.registerText);
        forgotPassword = findViewById(R.id.forgotPassword);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Btn.setOnClickListener(this);
        registerText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), RegisterAct.class));
                finish();
            }
        });
        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), forgotPassword.class));
                finish();
            }
        });

    }

    @Override
    public void onClick(View v) {
        if(v == Btn)
            signInUser();
    }
    public void ShowHidePass(View view){

        if(view.getId()==R.id.show_pass_btn){

            if(passwordEdit.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                ((AppCompatImageView)(view)).setImageResource(R.drawable.newp);

                //Show Password
                passwordEdit.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            }
            else{
                ((AppCompatImageView)(view)).setImageResource(R.drawable.capture);

                //Hide Password
                passwordEdit.setTransformationMethod(PasswordTransformationMethod.getInstance());

            }
        }
    }

    private void signInUser() {
        User user = new DAOclass().setData();
        stringRequest = new StringRequest(Request.Method.POST, Constants.LOGIN_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("ERROR", response);

                    if(response.equals("success"))
                    {
                        Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_SHORT).show();
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putString("eid", user.getUid());
                        editor.putString("password", user.getPassword());
                        editor.apply();
                        editor.commit();
                        startActivity(new Intent(getApplicationContext(), HomeAct.class));
                        finish();
                    }
                    else{
                        Toast.makeText(getApplicationContext(), "Failed", Toast.LENGTH_SHORT).show();
                    }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("ERROR", error.toString());
                //Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_SHORT).show();
            }
        })
        {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put(KEY_ID, user.getUid());
                hashMap.put(KEY_PASSWORD, user.getPassword());
                return hashMap;
            }
        };
        singleton = VolleySingleton.getInstance(this);
        singleton.addToRequestQueue(stringRequest);
    }

    public static class DAOclass{
        public User setData()
        {
            String eid = idEdit.getText().toString().trim();
            String password = passwordEdit.getText().toString().trim();
            if(TextUtils.isEmpty(eid))
                idEdit.setError("Please fill the field");
            else if(TextUtils.isEmpty(password))
                passwordEdit.setError("Please fill the field");
            else{
                User user = new User();
                user.setUid(eid);
                user.setPassword(password);
                return user;
            }
            return null;
        }
    }
}