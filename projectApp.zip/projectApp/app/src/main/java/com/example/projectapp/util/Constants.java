package com.example.projectapp.util;

public final class Constants {
    public static final String REG_URL = "https://aseproject2021.000webhostapp.com/register.php";
    public static final String LOGIN_URL = "https://aseproject2021.000webhostapp.com/login.php";
    public static final String IMAGE_URL = "https://aseproject2021.000webhostapp.com/upload.php";
    public static final String PROFILE_DATA = "https://aseproject2021.000webhostapp.com/mydata.php";
    public static final String UPLOAD_PRO = "https://aseproject2021.000webhostapp.com/uploadPro.php";
    public static final String PROFILE_PRO = "https://aseproject2021.000webhostapp.com/fetchtoprofile.php";
    public static final String HOME_PRO = "https://aseproject2021.000webhostapp.com/fetchtohome.php";
    public static final String DELETE_PRO = "https://aseproject2021.000webhostapp.com/deleteprofilepro.php";
    public static final String OWNER_DETAILS = "https://aseproject2021.000webhostapp.com/ownerDetails.php";
    public static final String BUYER_DETAILS = "https://aseproject2021.000webhostapp.com/buyer.php";
}
