package com.example.projectapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import com.example.projectapp.util.Constants;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import com.example.projectapp.model.User;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class RegisterAct extends AppCompatActivity implements View.OnClickListener {
    private static AppCompatEditText uid, textname, textcontact, textroom, textpassword;
    private AppCompatButton submit;
    private StringRequest stringRequest;
    private VolleySingleton singleton;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    private static final String KEY_ID = "eid";
    private static final String KEY_UNAME = "name";
    private static final String KEY_CONTACT = "contact";
    private static final String KEY_ROOM = "room";
    private static final String KEY_PASSWORD = "password";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().hide();
        init();
    }

    @Override
    protected void onResume() {
        super.onResume();
        submit.setOnClickListener(this);
    }

    private void init() {
        uid = findViewById(R.id.eid);
        textname = findViewById(R.id.textName);
        textcontact = findViewById(R.id.textcontact);
        textroom = findViewById(R.id.textroom);
        textpassword = findViewById(R.id.textpassword);
        submit = findViewById(R.id.submit);
    }

    @Override
    public void onClick(View v) {
        if(v == submit)
            registerUser();
    }

    private void registerUser() {
        User user = new DAOClass().setData();

        stringRequest = new StringRequest(Request.Method.POST, Constants.REG_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.i("INFO", response);
                        if (response.equals("success")) {
                            Toast.makeText(getApplicationContext(), "User Registered successfully", Toast.LENGTH_SHORT).show();
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.putString("eid", user.getUid());
                            editor.putString("name", user.getUname());
                            editor.putString("contact", user.getContact());
                            editor.putString("room", user.getRoomNo());
                            editor.putString("password", user.getPassword());
                            editor.apply();
                            editor.commit();
                            Intent intent = new Intent(getApplicationContext(), LoginAct.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                            finish();
                        }
                        else
                            Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        })
        {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put(KEY_ID, user.getUid());
                hashMap.put(KEY_UNAME, user.getUname());
                hashMap.put(KEY_CONTACT, user.getContact());
                hashMap.put(KEY_ROOM, user.getRoomNo());
                hashMap.put(KEY_PASSWORD, user.getPassword());

                return hashMap;
            }
        };

        singleton = VolleySingleton.getInstance(this);
        singleton.addToRequestQueue(stringRequest);
    }

    public static class DAOClass{
        public User setData()
        {
            String eid = uid.getText().toString().trim();
            String name = Objects.requireNonNull(textname.getText()).toString().trim();
            String contact = textcontact.getText().toString().trim();
            String room = textroom.getText().toString().trim();
            String password = textpassword.getText().toString().trim();
            if(TextUtils.isEmpty(eid))
                uid.setError("Plz fill the field");
            else if(TextUtils.isEmpty(name))
                textname.setError("Plz fill the fiels");
            else if(TextUtils.isEmpty(contact))
                textcontact.setError("Plz fill the fiels");
            else if(TextUtils.isEmpty(room))
                textroom.setError("Plz fill the fiels");
            else if(contact.length() < 8)
                textcontact.setError("Enter valid Contact");
            else if(TextUtils.isEmpty(password))
                textpassword.setError("Plz fill the fiels");
            else if(password.length() < 8)
                textpassword.setError("Enter valid password");
            else{
                User user = new User(eid, name, contact, room, password);
                return user;
            }
            return null;
        }
    }
}