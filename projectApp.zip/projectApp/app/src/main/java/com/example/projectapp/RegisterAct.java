package com.example.projectapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;

import com.example.projectapp.util.Constants;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import com.example.projectapp.model.User;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class RegisterAct extends AppCompatActivity implements View.OnClickListener {
    private static AppCompatEditText uid, textname, textcontact, textroom, textpassword, questionn;
    private AppCompatTextView loginBtn;
    private AppCompatButton submit;
    private StringRequest stringRequest;
    private VolleySingleton singleton;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    private static final String KEY_ID = "eid";
    private static final String KEY_UNAME = "name";
    private static final String KEY_CONTACT = "contact";
    private static final String KEY_ROOM = "room";
    private static final String KEY_QUESTION = "question";
    private static final String KEY_PASSWORD = "password";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().hide();
        init();
    }

    @Override
    protected void onResume() {
        super.onResume();
        submit.setOnClickListener(this);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), LoginAct.class));
                finish();
            }
        });
    }

    private void init() {
        uid = findViewById(R.id.eid);
        textname = findViewById(R.id.textName);
        textcontact = findViewById(R.id.textcontact);
        textroom = findViewById(R.id.textroom);
        questionn = findViewById(R.id.question);
        textpassword = findViewById(R.id.textpassword);
        loginBtn = findViewById(R.id.loginBtn);
        submit = findViewById(R.id.submit);



    }

    @Override
    public void onClick(View v) {
        if(v == submit)
            registerUser();
    }

    private void registerUser() {
        User user = new DAOClass().setData();

        stringRequest = new StringRequest(Request.Method.POST, Constants.REG_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.i("INFO", response);
                        if (response.equals("success")) {
                            Toast.makeText(getApplicationContext(), "Registered successfully", Toast.LENGTH_SHORT).show();
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    Intent intent = new Intent(getApplicationContext(), LoginAct.class);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(intent);
                                    finish();
                                }
                            },2000);

                        }
                        else
                            Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("ERROR", error.toString());
                Toast.makeText(getApplicationContext(), "Please fill the fields", Toast.LENGTH_SHORT).show();
            }
        })
        {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put(KEY_ID, user.getUid());
                hashMap.put(KEY_UNAME, user.getUname());
                hashMap.put(KEY_CONTACT, user.getContact());
                hashMap.put(KEY_ROOM, user.getRoomNo());
                hashMap.put(KEY_QUESTION, user.getQuestion());
                hashMap.put(KEY_PASSWORD, user.getPassword());

                return hashMap;
            }
        };

        singleton = VolleySingleton.getInstance(this);
        singleton.addToRequestQueue(stringRequest);
    }

    public static class DAOClass{
        public User setData()
        {
            String eid = uid.getText().toString().trim();
            String name = Objects.requireNonNull(textname.getText()).toString().trim();
            String contact = textcontact.getText().toString().trim();
            String room = textroom.getText().toString().trim();
            String password = textpassword.getText().toString().trim();
            String question = questionn.getText().toString().trim();
            if(TextUtils.isEmpty(eid))
                uid.setError("Plz fill the field");
            else if(eid.charAt(0) == 'a' || eid.charAt(1) == 'u')
                uid.setError("Please enter capital alphabets");
            else if(eid.length()<9 || eid.charAt(0) != 'A' || eid.charAt(1) != 'U')
                uid.setError("Please enter Valid Enrollment ID");
            else if(TextUtils.isEmpty(name))
                textname.setError("Please fill the field");
            else if(TextUtils.isEmpty(contact))
                textcontact.setError("Please fill the field");
            else if(contact.length()!=10)
                textcontact.setError("Please enter valid contact number");
            else if(TextUtils.isEmpty(question))
                questionn.setError("Please fill the field");
            else if(TextUtils.isEmpty(password))
                textpassword.setError("Please fill the field");
            else if(password.length() < 8)
                textpassword.setError("Please enter a 8 digit password");
            else{
                User user = new User(eid, name, contact, room, question, password);
                return user;
            }
            return null;
        }
    }
}