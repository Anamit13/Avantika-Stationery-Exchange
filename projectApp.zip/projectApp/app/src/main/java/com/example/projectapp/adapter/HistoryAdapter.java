package com.example.projectapp.adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projectapp.R;
import com.example.projectapp.model.History;

import java.util.ArrayList;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.HistoryHolder> {
    private Context context;
    private ArrayList<History> arrayList;

    public HistoryAdapter(Context context, ArrayList<History> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public HistoryAdapter.HistoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.historycard, parent, false);
        return new HistoryHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryAdapter.HistoryHolder holder, int position) {
        History mHistory =arrayList.get(position);
        holder.histpro.setText(mHistory.getProduct());
        holder.histsell.setText(mHistory.getSeller());
        holder.histbuy.setText(mHistory.getBuyer());
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public static class HistoryHolder extends RecyclerView.ViewHolder{
        private AppCompatTextView histpro, histsell, histbuy;


        public HistoryHolder(@NonNull View itemView) {
            super(itemView);
            histpro = itemView.findViewById(R.id.histPro);
            histsell = itemView.findViewById(R.id.histSell);
            histbuy = itemView.findViewById(R.id.hisBuy);
        }
    }
}
