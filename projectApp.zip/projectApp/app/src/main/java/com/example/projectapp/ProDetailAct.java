package com.example.projectapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatTextView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.appbar.AppBarLayout;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProDetailAct extends AppCompatActivity {
    private CircleImageView detailimage;
    private AppCompatTextView detailpname, detaildesc, detailop, detailsp, detailownership;
    private AppCompatButton buyProduct;
    String eid = "";
    private static SharedPreferences preferences;
    private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#1E0233"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setTitle("ASE");
        preferences = getSharedPreferences("mypref", MODE_PRIVATE);
        editor = preferences.edit();
        setContentView(R.layout.activity_pro_detail);
        detailimage = findViewById(R.id.detailpimage);
        detailpname = findViewById(R.id.detailpname);
        detaildesc = findViewById(R.id.detaildesc);
        detailop = findViewById(R.id.detailop);
        detailsp = findViewById(R.id.detailsp);
        detailownership = findViewById(R.id.detailOwnership);
        buyProduct = findViewById(R.id.buyProduct);
    }

    @Override
    protected void onResume() {
        super.onResume();

        Bundle bundle = getIntent().getExtras();
        if(bundle != null)
        {
            Picasso.get().load(String.valueOf(bundle.getCharSequence("pimage"))).into(detailimage);
            detailpname.setText(bundle.getCharSequence("pname"));
            detaildesc.setText(bundle.getCharSequence("pdesc"));
            detailop.setText(bundle.getCharSequence("oprice"));
            detailsp.setText(bundle.getCharSequence("sprice"));
            detailownership.setText(bundle.getCharSequence("ownership"));
            eid = bundle.getString("eid");
        }
        buyProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle1 = new Bundle();
                Intent intent = new Intent(getApplicationContext(), ProBuyAct.class);
                bundle1.putString("eid", eid);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id =item.getItemId();
        if(id == R.id.logout)
        {
            editor = preferences.edit();
            editor.remove("eid");
            editor.remove("password");
            editor.clear();
            editor.apply();
            Intent intent = new Intent(getApplicationContext(), LoginAct.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }
        else if(id == R.id.profile)
        {
            Intent intent = new Intent(getApplicationContext(), ProfileAct.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
        else if(id == R.id.history1)
        {
            startActivity(new Intent(getApplicationContext(), History.class));
        }
        else if(id == R.id.home)
        {
            startActivity(new Intent(getApplicationContext(), HomeAct.class));
        }
        return true;
    }
}