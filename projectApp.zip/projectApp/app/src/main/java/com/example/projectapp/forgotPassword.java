package com.example.projectapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.projectapp.util.Constants;

import java.util.HashMap;
import java.util.Map;

public class forgotPassword extends AppCompatActivity {
    private AppCompatEditText reEnroll, reQuestion, rePassword;
    private AppCompatButton reset;
    private StringRequest stringRequest;
    private VolleySingleton singleton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        init();
        getSupportActionBar().hide();
    }

    private void init() {
        reEnroll = findViewById(R.id.reEnroll);
        reQuestion = findViewById(R.id.reQuestion);
        rePassword = findViewById(R.id.rePassword);
        reset = findViewById(R.id.reset);
    }

    @Override
    protected void onResume() {
        super.onResume();
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                forgotpassword();
            }
        });
    }

    private void forgotpassword() {
        String eid = reEnroll.getText().toString().trim();
        String question = reQuestion.getText().toString().trim();
        String password = rePassword.getText().toString().trim();
        if(TextUtils.isEmpty(eid))
            reEnroll.setError("Please fill the field");
        else if(TextUtils.isEmpty(question))
            reQuestion.setError("Please fill the field");
        else if(TextUtils.isEmpty(password))
            rePassword.setError("Please fill the field");
        else{
            stringRequest = new StringRequest(Request.Method.POST, Constants.FORGOT_PASSWORD, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.i("INFO", response);
                    if(response.equals("success"))
                        Toast.makeText(getApplicationContext(), "Password reset successful", Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(getApplicationContext(), "Password reset successful", Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("ERROR", error.toString());
                    Toast.makeText(getApplicationContext(), "Please fill the fields", Toast.LENGTH_SHORT).show();
                }
            })
            {
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> hashMap = new HashMap<>();
                    hashMap.put("eid", eid);
                    hashMap.put("question", question);
                    hashMap.put("password", password);
                    return hashMap;
                }
            };
            singleton = VolleySingleton.getInstance(this);
            singleton.addToRequestQueue(stringRequest);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    startActivity(new Intent(getApplicationContext(), LoginAct.class));
                    finish();
                }
            }, 4000);

        }
    }
}