package com.example.projectapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatSpinner;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.projectapp.model.Product;
import com.example.projectapp.model.User;
import com.example.projectapp.util.Constants;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;

public class AddProAct extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;
    private CircleImageView uploadproimg;
    private AppCompatImageView clickproimg;
    private static AppCompatEditText uploadproname, uploadprodesc, uploadproop, uploadprosp;
    private AppCompatButton uploadProbtn;
    private StringRequest stringRequest;
    private VolleySingleton singleton;
    private static SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    private Bitmap bitmap;
    private static AppCompatSpinner uploadproownership;
    private String[] ownership;
    private static String item = null;
    private static final String KEY_ID = "eid";
    private static final String KEY_PNAME = "pname";
    private static final String KEY_PDESC = "pdesc";
    private static final String KEY_OPRICE = "oprice";
    private static final String KEY_SPRICE = "sprice";
    private static final String KEY_OWNERSHIP = "ownership";
    private static final String KEY_PIMAGE = "pimage";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_pro);
        ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#1E0233"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setTitle("ASE");
        init();
        ownership = getResources().getStringArray(R.array.ownership);
        preferences = getSharedPreferences("mypref", MODE_PRIVATE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ArrayAdapter<String> arrayAdapter  = new ArrayAdapter<String>(AddProAct.this, R.layout.spinner_list, ownership)
        {
            @Override
            public boolean isEnabled(int position) {

                if (position > 0) {
                    return true;
                } else {
                    return false;
                }
            }

        };
        arrayAdapter.setDropDownViewResource(R.layout.spinner_list);
        uploadproownership.setAdapter(arrayAdapter);
        uploadproownership.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position > 0){
                    item = (String) parent.getItemAtPosition(position);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        clickproimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v == clickproimg)
                    pickImage();
            }
        });
        uploadProbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v == uploadProbtn)
                    uploadProduct();
            }
        });
    }

    private void uploadProduct() {
        String eid = preferences.getString("eid", "");
        String pname = Objects.requireNonNull(uploadproname.getText()).toString().trim();
        String pdesc = Objects.requireNonNull(uploadprodesc.getText()).toString().trim();
        String oprice = Objects.requireNonNull(uploadproop.getText()).toString().trim();
        String sprice = Objects.requireNonNull(uploadprosp.getText()).toString().trim();
        String ownership = item;
        String imgurl = getStringImage(bitmap);
        if(imgurl != null && ownership != null && eid != null)
        {
            stringRequest = new StringRequest(Request.Method.POST, Constants.UPLOAD_PRO, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.i("INFO", response);
                    if(response.equals("success"))
                    {
                        Toast.makeText(getApplicationContext(), "Product Uploaded", Toast.LENGTH_SHORT).show();
                    }
                    else
                        Toast.makeText(getApplicationContext(), "Not Uploaded", Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("ERROR", error.toString());
                    Toast.makeText(getApplicationContext(), "Please fill the fields", Toast.LENGTH_SHORT).show();
                }
            })
            {
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> hashMap = new HashMap<>();
                    hashMap.put(KEY_ID, eid);
                    hashMap.put(KEY_PNAME, pname);
                    hashMap.put(KEY_PDESC, pdesc);
                    hashMap.put(KEY_OPRICE, oprice);
                    hashMap.put(KEY_SPRICE, sprice);
                    hashMap.put(KEY_OWNERSHIP, ownership);
                    hashMap.put(KEY_PIMAGE, imgurl);
                    return hashMap;
                }
            };
            singleton = VolleySingleton.getInstance(this);
            singleton.addToRequestQueue(stringRequest);
        }
        else
            Toast.makeText(getApplicationContext(), "Enter All the fields", Toast.LENGTH_LONG).show();

    }

    public void pickImage(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"),
                PICK_IMAGE_REQUEST);
    }
    private String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST &&
                resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri filePath = data.getData();
            try {
                //Getting the Bitmap from Gallery
                uploadproimg.setVisibility(View.VISIBLE);
                bitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), filePath);
                //Setting the Bitmap to ImageView
                uploadproimg.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    private void init() {
        uploadproimg = findViewById(R.id.uploadproimg);
        clickproimg = findViewById(R.id.clickproimg);
        uploadproname = findViewById(R.id.uploadproname);
        uploadprodesc = findViewById(R.id.uploadprodesc);
        uploadproop = findViewById(R.id.uploadproop);
        uploadprosp = findViewById(R.id.uploadprosp);
        uploadproownership = findViewById(R.id.uploadproownership);
        uploadProbtn = findViewById(R.id.uploadProbtn);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id =item.getItemId();
        if(id == R.id.logout)
        {
            editor = preferences.edit();
            editor.remove("eid");
            editor.remove("password");
            editor.clear();
            editor.apply();
            Intent intent = new Intent(getApplicationContext(), LoginAct.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }
        else if(id == R.id.profile)
        {
            Intent intent = new Intent(getApplicationContext(), ProfileAct.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
        else if(id == R.id.history1)
        {
            startActivity(new Intent(getApplicationContext(), History.class));
        }
        else if(id == R.id.home)
        {
            startActivity(new Intent(getApplicationContext(), HomeAct.class));
        }
        return true;
    }

}