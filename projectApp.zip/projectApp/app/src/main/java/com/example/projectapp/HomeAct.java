package com.example.projectapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.projectapp.adapter.HomeAdapter;
import com.example.projectapp.model.Product;
import com.example.projectapp.util.Constants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HomeAct extends AppCompatActivity implements HomeAdapter.onItemClickListener {
    private AppCompatImageView uppro;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    private VolleySingleton singleton1;
    private VolleySingleton singleton;
    private StringRequest stringRequest1;
    private StringRequest stringRequest;
    private Bitmap bitmap;
    private RecyclerView recyclerViewhome;
    private HomeAdapter adapter;
    private ArrayList<Product> products;
    public static final String KEY_ID = "eid";
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#1E0233"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setTitle("ASE");
        preferences = getSharedPreferences("mypref", MODE_PRIVATE);
        Intent intent = getIntent();
        uppro = findViewById(R.id.upproduct);
        recyclerViewhome = findViewById(R.id.recyclerViewHome);
        recyclerViewhome.setLayoutManager(new GridLayoutManager(this, 1));
        recyclerViewhome.setHasFixedSize(true);
        products = new ArrayList<>();
        progressDialog = new ProgressDialog(this);


    }

    @Override
    protected void onResume() {
        super.onResume();
        profileData();
        uppro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v == uppro)
                {
                    startActivity(new Intent(getApplicationContext(), AddProAct.class));
                }
            }
        });
        getHomePro();
    }

    private void getHomePro() {
        products.clear();
        progressDialog.setCancelable(false);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Loading.... Please wait");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.create();
        progressDialog.show();
        stringRequest = new StringRequest(Request.Method.GET, Constants.HOME_PRO, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("INFO", response);
                progressDialog.dismiss();
                try{
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    for(int i = 0; i < jsonArray.length(); i++)
                    {
                        JSONObject jOBj = jsonArray.getJSONObject(i);
                        Product mProducts = new Product(jOBj.getString("eid"), jOBj.getString("pname"), jOBj.getString("pdesc"),
                                jOBj.getString("oprice"), jOBj.getString("sprice"), jOBj.getString("ownership"),
                                jOBj.getString("pimage"));
                        products.add(mProducts);
                    }
                    adapter = new HomeAdapter(HomeAct.this, products);
                    recyclerViewhome.setAdapter(adapter);
                    adapter.setOnItemClickListener(HomeAct.this);
                } catch (JSONException ex)
                {
                    progressDialog.cancel();
                    Log.e("ERROR", ex.getMessage());
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("ERROR", error.toString());
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        });
        singleton = VolleySingleton.getInstance(this);
        singleton.addToRequestQueue(stringRequest);
    }

    public void profileData()
    {
        stringRequest1 = new StringRequest(Request.Method.DEPRECATED_GET_OR_POST, Constants.PROFILE_DATA, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("INFO", response);
                //Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                try {
                    JSONObject obj = new JSONObject(response);

                    editor = preferences.edit();
                    editor.putString("name", obj.getString("name"));
                    editor.putString("contact", obj.getString("contact"));
                    editor.putString("room", obj.getString("room"));
                    editor.putString("image", obj.getString("image"));
                    editor.apply();
                    editor.commit();
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.e("ERROR", e.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("ERROR", error.getMessage());
                //Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        })
        {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put(KEY_ID, preferences.getString("eid", ""));
                return hashMap;
            }
        };
        singleton1 =VolleySingleton.getInstance(this);
        singleton1.addToRequestQueue(stringRequest1);
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id =item.getItemId();
        if(id == R.id.logout)
        {
            editor = preferences.edit();
            editor.remove("eid");
            editor.remove("password");
            editor.clear();
            editor.apply();
            Intent intent = new Intent(getApplicationContext(), LoginAct.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }
        else if(id == R.id.profile)
        {
            Intent intent = new Intent(getApplicationContext(), ProfileAct.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
        else if(id == R.id.history1)
        {
            startActivity(new Intent(getApplicationContext(), History.class));
        }
        else if(id == R.id.home)
        {
            startActivity(new Intent(getApplicationContext(), HomeAct.class));
        }
        return true;
    }

    @Override
    public void onItemClick(int position) {
        Bundle bundle = new Bundle();
        Product mproduct = products.get(position);
        Intent intent = new Intent(getApplicationContext(), ProDetailAct.class);
        bundle.putString("eid", mproduct.getEid());
        bundle.putString("pname", mproduct.getPname());
        bundle.putString("pdesc", mproduct.getPdesc());
        bundle.putString("oprice", mproduct.getOprice());
        bundle.putString("sprice", mproduct.getSprice());
        bundle.putString("ownership", mproduct.getOwnership());
        bundle.putString("pimage", mproduct.getPimage());
        intent.putExtras(bundle);
        startActivity(intent);
    }
}